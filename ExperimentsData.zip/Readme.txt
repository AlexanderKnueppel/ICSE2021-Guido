Contains:
- KeY: data basis, hypotheses, and experiments to eval. hypotheses for the program verifier KeY
- CPAChecker: data basis, hypotheses, and and experiments to eval. hypotheses for the model checker CPAChecker

The 'R' folder of each verifier contains all experiments to evaluate the hypotheses. Job-files describe the verification tasks.

For key, we included all verification subjects. For CpaChecker, please see the job file and visit https://github.com/sosy-lab/sv-benchmarks to find the becnhmarks.