base <- "F:/Homeoffice/ResearchProjects/ICSE21-Guido/framework/Guido/Plugins/de.tubs.isf.guido.evaluation/./testData/keyproject/R/experiments/"
pvector = c()

#STOP AT (Hypothesis: H0)
filename <- paste(sep="",base,"H0.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
if(nrow(dataFilter) > 0)  {
	dataAN <- as.numeric(dataFilter$Effort...A)
	dataBN <- as.numeric(dataFilter$Effort...B)
	testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "greater")
	testresult
	pvector = c(testresult$p.value)
} else {
pvector = c(1.0)
}

#ONE STEP SIMPLIFICATION (Hypothesis: H1)
filename <- paste(sep="",base,"H1.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
if(nrow(dataFilter) > 0)  {
	dataAN <- as.numeric(dataFilter$Effort...A)
	dataBN <- as.numeric(dataFilter$Effort...B)
	testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "less")
	testresult
	pvector = c(pvector, testresult$p.value)
} else {
pvector = c(pvector, 1.0)
}

#PROOF SPLITTING (Hypothesis: H2)
filename <- paste(sep="",base,"H2__H3.txt")
results <- read.table(filename, header = TRUE, sep = '|')
results$Closed...A <- ordered(results$Closed...A, levels = c("", "X"))
results$Closed...B <- ordered(results$Closed...B, levels = c("", "X"))
dataAC <- as.numeric(results$Closed...A)
dataBC <- as.numeric(results$Closed...B)
dataAC[is.na(dataAC)] <- 1
dataBC[is.na(dataAC)] <- 1
dataAC <- c(dataAC, 1)
dataBC <- c(dataBC, 1)
dataAC <- c(dataAC, 2)
dataBC <- c(dataBC, 2)
if(identical(dataAC,dataBC)) {
pvector = c(pvector, 1.0)
} else {
	testresult <- mcnemar.test(dataAC,dataBC)
	testresult
	pvector = c(pvector, testresult$p.value)
}

#PROOF SPLITTING (Hypothesis: H3)
filename <- paste(sep="",base,"H2__H3.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
if(nrow(dataFilter) > 0)  {
	dataAN <- as.numeric(dataFilter$Effort...A)
	dataBN <- as.numeric(dataFilter$Effort...B)
	testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "less")
	testresult
	pvector = c(pvector, testresult$p.value)
} else {
pvector = c(pvector, 1.0)
}

#PROOF SPLITTING (Hypothesis: H4)
filename <- paste(sep="",base,"H4.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
if(nrow(dataFilter) > 0)  {
	dataAN <- as.numeric(dataFilter$Effort...A)
	dataBN <- as.numeric(dataFilter$Effort...B)
	testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "greater")
	testresult
	pvector = c(pvector, testresult$p.value)
} else {
pvector = c(pvector, 1.0)
}

#PROOF SPLITTING (Hypothesis: H5)
filename <- paste(sep="",base,"H5.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
if(nrow(dataFilter) > 0)  {
	dataAN <- as.numeric(dataFilter$Effort...A)
	dataBN <- as.numeric(dataFilter$Effort...B)
	testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "greater")
	testresult
	pvector = c(pvector, testresult$p.value)
} else {
pvector = c(pvector, 1.0)
}

#PROOF SPLITTING (Hypothesis: H6)
filename <- paste(sep="",base,"H6__H8.txt")
results <- read.table(filename, header = TRUE, sep = '|')
results$Closed...A <- ordered(results$Closed...A, levels = c("", "X"))
results$Closed...B <- ordered(results$Closed...B, levels = c("", "X"))
dataAC <- as.numeric(results$Closed...A)
dataBC <- as.numeric(results$Closed...B)
dataAC[is.na(dataAC)] <- 1
dataBC[is.na(dataAC)] <- 1
dataAC <- c(dataAC, 1)
dataBC <- c(dataBC, 1)
dataAC <- c(dataAC, 2)
dataBC <- c(dataBC, 2)
if(identical(dataAC,dataBC)) {
pvector = c(pvector, 1.0)
} else {
	testresult <- mcnemar.test(dataAC,dataBC)
	testresult
	pvector = c(pvector, testresult$p.value)
}

#PROOF SPLITTING (Hypothesis: H7)
filename <- paste(sep="",base,"H7__H9.txt")
results <- read.table(filename, header = TRUE, sep = '|')
results$Closed...A <- ordered(results$Closed...A, levels = c("", "X"))
results$Closed...B <- ordered(results$Closed...B, levels = c("", "X"))
dataAC <- as.numeric(results$Closed...A)
dataBC <- as.numeric(results$Closed...B)
dataAC[is.na(dataAC)] <- 1
dataBC[is.na(dataAC)] <- 1
dataAC <- c(dataAC, 1)
dataBC <- c(dataBC, 1)
dataAC <- c(dataAC, 2)
dataBC <- c(dataBC, 2)
if(identical(dataAC,dataBC)) {
pvector = c(pvector, 1.0)
} else {
	testresult <- mcnemar.test(dataAC,dataBC)
	testresult
	pvector = c(pvector, testresult$p.value)
}

#PROOF SPLITTING (Hypothesis: H8)
filename <- paste(sep="",base,"H6__H8.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
if(nrow(dataFilter) > 0)  {
	dataAN <- as.numeric(dataFilter$Effort...A)
	dataBN <- as.numeric(dataFilter$Effort...B)
	testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "less")
	testresult
	pvector = c(pvector, testresult$p.value)
} else {
pvector = c(pvector, 1.0)
}

#PROOF SPLITTING (Hypothesis: H9)
filename <- paste(sep="",base,"H7__H9.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
if(nrow(dataFilter) > 0)  {
	dataAN <- as.numeric(dataFilter$Effort...A)
	dataBN <- as.numeric(dataFilter$Effort...B)
	testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "less")
	testresult
	pvector = c(pvector, testresult$p.value)
} else {
pvector = c(pvector, 1.0)
}

#PROOF SPLITTING (Hypothesis: H10)
filename <- paste(sep="",base,"H10.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
if(nrow(dataFilter) > 0)  {
	dataAN <- as.numeric(dataFilter$Effort...A)
	dataBN <- as.numeric(dataFilter$Effort...B)
	testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "less")
	testresult
	pvector = c(pvector, testresult$p.value)
} else {
pvector = c(pvector, 1.0)
}

#PROOF SPLITTING (Hypothesis: H11)
filename <- paste(sep="",base,"H11.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
if(nrow(dataFilter) > 0)  {
	dataAN <- as.numeric(dataFilter$Effort...A)
	dataBN <- as.numeric(dataFilter$Effort...B)
	testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "less")
	testresult
	pvector = c(pvector, testresult$p.value)
} else {
pvector = c(pvector, 1.0)
}

#PROOF SPLITTING (Hypothesis: H12)
filename <- paste(sep="",base,"H12.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
if(nrow(dataFilter) > 0)  {
	dataAN <- as.numeric(dataFilter$Effort...A)
	dataBN <- as.numeric(dataFilter$Effort...B)
	testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "greater")
	testresult
	pvector = c(pvector, testresult$p.value)
} else {
pvector = c(pvector, 1.0)
}

#PROOF SPLITTING (Hypothesis: H13)
filename <- paste(sep="",base,"H13.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
if(nrow(dataFilter) > 0)  {
	dataAN <- as.numeric(dataFilter$Effort...A)
	dataBN <- as.numeric(dataFilter$Effort...B)
	testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "greater")
	testresult
	pvector = c(pvector, testresult$p.value)
} else {
pvector = c(pvector, 1.0)
}

#LOOP TREATMENT (Hypothesis: H14)
filename <- paste(sep="",base,"H14__H15.txt")
results <- read.table(filename, header = TRUE, sep = '|')
results$Closed...A <- ordered(results$Closed...A, levels = c("", "X"))
results$Closed...B <- ordered(results$Closed...B, levels = c("", "X"))
dataAC <- as.numeric(results$Closed...A)
dataBC <- as.numeric(results$Closed...B)
dataAC[is.na(dataAC)] <- 1
dataBC[is.na(dataAC)] <- 1
dataAC <- c(dataAC, 1)
dataBC <- c(dataBC, 1)
dataAC <- c(dataAC, 2)
dataBC <- c(dataBC, 2)
if(identical(dataAC,dataBC)) {
pvector = c(pvector, 1.0)
} else {
	testresult <- mcnemar.test(dataAC,dataBC)
	testresult
	pvector = c(pvector, testresult$p.value)
}

#LOOP TREATMENT (Hypothesis: H15)
filename <- paste(sep="",base,"H14__H15.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
if(nrow(dataFilter) > 0)  {
	dataAN <- as.numeric(dataFilter$Effort...A)
	dataBN <- as.numeric(dataFilter$Effort...B)
	testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "greater")
	testresult
	pvector = c(pvector, testresult$p.value)
} else {
pvector = c(pvector, 1.0)
}

#DEPENDENCY CONTRACTS (Hypothesis: H16)
filename <- paste(sep="",base,"H16__H17.txt")
results <- read.table(filename, header = TRUE, sep = '|')
results$Closed...A <- ordered(results$Closed...A, levels = c("", "X"))
results$Closed...B <- ordered(results$Closed...B, levels = c("", "X"))
dataAC <- as.numeric(results$Closed...A)
dataBC <- as.numeric(results$Closed...B)
dataAC[is.na(dataAC)] <- 1
dataBC[is.na(dataAC)] <- 1
dataAC <- c(dataAC, 1)
dataBC <- c(dataBC, 1)
dataAC <- c(dataAC, 2)
dataBC <- c(dataBC, 2)
if(identical(dataAC,dataBC)) {
pvector = c(pvector, 1.0)
} else {
	testresult <- mcnemar.test(dataAC,dataBC)
	testresult
	pvector = c(pvector, testresult$p.value)
}

#DEPENDENCY CONTRACTS (Hypothesis: H17)
filename <- paste(sep="",base,"H16__H17.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
if(nrow(dataFilter) > 0)  {
	dataAN <- as.numeric(dataFilter$Effort...A)
	dataBN <- as.numeric(dataFilter$Effort...B)
	testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "two.sided")
	testresult
	pvector = c(pvector, testresult$p.value)
} else {
pvector = c(pvector, 1.0)
}

#QUERY TREATMENT (Hypothesis: H18)
filename <- paste(sep="",base,"H18.txt")
results <- read.table(filename, header = TRUE, sep = '|')
results$Closed...A <- ordered(results$Closed...A, levels = c("", "X"))
results$Closed...B <- ordered(results$Closed...B, levels = c("", "X"))
dataAC <- as.numeric(results$Closed...A)
dataBC <- as.numeric(results$Closed...B)
dataAC[is.na(dataAC)] <- 1
dataBC[is.na(dataAC)] <- 1
dataAC <- c(dataAC, 1)
dataBC <- c(dataBC, 1)
dataAC <- c(dataAC, 2)
dataBC <- c(dataBC, 2)
if(identical(dataAC,dataBC)) {
pvector = c(pvector, 1.0)
} else {
	testresult <- mcnemar.test(dataAC,dataBC)
	testresult
	pvector = c(pvector, testresult$p.value)
}

#QUERY TREATMENT (Hypothesis: H19)
filename <- paste(sep="",base,"H19.txt")
results <- read.table(filename, header = TRUE, sep = '|')
results$Closed...A <- ordered(results$Closed...A, levels = c("", "X"))
results$Closed...B <- ordered(results$Closed...B, levels = c("", "X"))
dataAC <- as.numeric(results$Closed...A)
dataBC <- as.numeric(results$Closed...B)
dataAC[is.na(dataAC)] <- 1
dataBC[is.na(dataAC)] <- 1
dataAC <- c(dataAC, 1)
dataBC <- c(dataBC, 1)
dataAC <- c(dataAC, 2)
dataBC <- c(dataBC, 2)
if(identical(dataAC,dataBC)) {
pvector = c(pvector, 1.0)
} else {
	testresult <- mcnemar.test(dataAC,dataBC)
	testresult
	pvector = c(pvector, testresult$p.value)
}

#EXPAND LOCAL QUERIES (Hypothesis: H20)
filename <- paste(sep="",base,"H20__H21.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
if(nrow(dataFilter) > 0)  {
	dataAN <- as.numeric(dataFilter$Effort...A)
	dataBN <- as.numeric(dataFilter$Effort...B)
	testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "greater")
	testresult
	pvector = c(pvector, testresult$p.value)
} else {
pvector = c(pvector, 1.0)
}

#EXPAND LOCAL QUERIES (Hypothesis: H21)
filename <- paste(sep="",base,"H20__H21.txt")
results <- read.table(filename, header = TRUE, sep = '|')
results$Closed...A <- ordered(results$Closed...A, levels = c("", "X"))
results$Closed...B <- ordered(results$Closed...B, levels = c("", "X"))
dataAC <- as.numeric(results$Closed...A)
dataBC <- as.numeric(results$Closed...B)
dataAC[is.na(dataAC)] <- 1
dataBC[is.na(dataAC)] <- 1
dataAC <- c(dataAC, 1)
dataBC <- c(dataBC, 1)
dataAC <- c(dataAC, 2)
dataBC <- c(dataBC, 2)
if(identical(dataAC,dataBC)) {
pvector = c(pvector, 1.0)
} else {
	testresult <- mcnemar.test(dataAC,dataBC)
	testresult
	pvector = c(pvector, testresult$p.value)
}

#ARITHMETIC TREATMENT (Hypothesis: H22)
filename <- paste(sep="",base,"H22.txt")
results <- read.table(filename, header = TRUE, sep = '|')
results$Closed...A <- ordered(results$Closed...A, levels = c("", "X"))
results$Closed...B <- ordered(results$Closed...B, levels = c("", "X"))
dataAC <- as.numeric(results$Closed...A)
dataBC <- as.numeric(results$Closed...B)
dataAC[is.na(dataAC)] <- 1
dataBC[is.na(dataAC)] <- 1
dataAC <- c(dataAC, 1)
dataBC <- c(dataBC, 1)
dataAC <- c(dataAC, 2)
dataBC <- c(dataBC, 2)
if(identical(dataAC,dataBC)) {
pvector = c(pvector, 1.0)
} else {
	testresult <- mcnemar.test(dataAC,dataBC)
	testresult
	pvector = c(pvector, testresult$p.value)
}

#ARITHMETIC TREATMENT (Hypothesis: H23)
filename <- paste(sep="",base,"H23__H25__H27.txt")
results <- read.table(filename, header = TRUE, sep = '|')
results$Closed...A <- ordered(results$Closed...A, levels = c("", "X"))
results$Closed...B <- ordered(results$Closed...B, levels = c("", "X"))
dataAC <- as.numeric(results$Closed...A)
dataBC <- as.numeric(results$Closed...B)
dataAC[is.na(dataAC)] <- 1
dataBC[is.na(dataAC)] <- 1
dataAC <- c(dataAC, 1)
dataBC <- c(dataBC, 1)
dataAC <- c(dataAC, 2)
dataBC <- c(dataBC, 2)
if(identical(dataAC,dataBC)) {
pvector = c(pvector, 1.0)
} else {
	testresult <- mcnemar.test(dataAC,dataBC)
	testresult
	pvector = c(pvector, testresult$p.value)
}

#ARITHMETIC TREATMENT (Hypothesis: H24)
filename <- paste(sep="",base,"H24__H26.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
if(nrow(dataFilter) > 0)  {
	dataAN <- as.numeric(dataFilter$Effort...A)
	dataBN <- as.numeric(dataFilter$Effort...B)
	testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "greater")
	testresult
	pvector = c(pvector, testresult$p.value)
} else {
pvector = c(pvector, 1.0)
}

#ARITHMETIC TREATMENT (Hypothesis: H25)
filename <- paste(sep="",base,"H23__H25__H27.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
if(nrow(dataFilter) > 0)  {
	dataAN <- as.numeric(dataFilter$Effort...A)
	dataBN <- as.numeric(dataFilter$Effort...B)
	testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "greater")
	testresult
	pvector = c(pvector, testresult$p.value)
} else {
pvector = c(pvector, 1.0)
}

#ARITHMETIC TREATMENT (Hypothesis: H26)
filename <- paste(sep="",base,"H24__H26.txt")
results <- read.table(filename, header = TRUE, sep = '|')
results$Closed...A <- ordered(results$Closed...A, levels = c("", "X"))
results$Closed...B <- ordered(results$Closed...B, levels = c("", "X"))
dataAC <- as.numeric(results$Closed...A)
dataBC <- as.numeric(results$Closed...B)
dataAC[is.na(dataAC)] <- 1
dataBC[is.na(dataAC)] <- 1
dataAC <- c(dataAC, 1)
dataBC <- c(dataBC, 1)
dataAC <- c(dataAC, 2)
dataBC <- c(dataBC, 2)
if(identical(dataAC,dataBC)) {
pvector = c(pvector, 1.0)
} else {
	testresult <- mcnemar.test(dataAC,dataBC)
	testresult
	pvector = c(pvector, testresult$p.value)
}

#ARITHMETIC TREATMENT (Hypothesis: H27)
filename <- paste(sep="",base,"H23__H25__H27.txt")
results <- read.table(filename, header = TRUE, sep = '|')
results$Closed...A <- ordered(results$Closed...A, levels = c("", "X"))
results$Closed...B <- ordered(results$Closed...B, levels = c("", "X"))
dataAC <- as.numeric(results$Closed...A)
dataBC <- as.numeric(results$Closed...B)
dataAC[is.na(dataAC)] <- 1
dataBC[is.na(dataAC)] <- 1
dataAC <- c(dataAC, 1)
dataBC <- c(dataBC, 1)
dataAC <- c(dataAC, 2)
dataBC <- c(dataBC, 2)
if(identical(dataAC,dataBC)) {
pvector = c(pvector, 1.0)
} else {
	testresult <- mcnemar.test(dataAC,dataBC)
	testresult
	pvector = c(pvector, testresult$p.value)
}

#QUANTIFIER TREATMENT (Hypothesis: H28)
filename <- paste(sep="",base,"H28.txt")
results <- read.table(filename, header = TRUE, sep = '|')
results$Closed...A <- ordered(results$Closed...A, levels = c("", "X"))
results$Closed...B <- ordered(results$Closed...B, levels = c("", "X"))
dataAC <- as.numeric(results$Closed...A)
dataBC <- as.numeric(results$Closed...B)
dataAC[is.na(dataAC)] <- 1
dataBC[is.na(dataAC)] <- 1
dataAC <- c(dataAC, 1)
dataBC <- c(dataBC, 1)
dataAC <- c(dataAC, 2)
dataBC <- c(dataBC, 2)
if(identical(dataAC,dataBC)) {
pvector = c(pvector, 1.0)
} else {
	testresult <- mcnemar.test(dataAC,dataBC)
	testresult
	pvector = c(pvector, testresult$p.value)
}

#QUANTIFIER TREATMENT (Hypothesis: H29)
filename <- paste(sep="",base,"H29__H32.txt")
results <- read.table(filename, header = TRUE, sep = '|')
results$Closed...A <- ordered(results$Closed...A, levels = c("", "X"))
results$Closed...B <- ordered(results$Closed...B, levels = c("", "X"))
dataAC <- as.numeric(results$Closed...A)
dataBC <- as.numeric(results$Closed...B)
dataAC[is.na(dataAC)] <- 1
dataBC[is.na(dataAC)] <- 1
dataAC <- c(dataAC, 1)
dataBC <- c(dataBC, 1)
dataAC <- c(dataAC, 2)
dataBC <- c(dataBC, 2)
if(identical(dataAC,dataBC)) {
pvector = c(pvector, 1.0)
} else {
	testresult <- mcnemar.test(dataAC,dataBC)
	testresult
	pvector = c(pvector, testresult$p.value)
}

#QUANTIFIER TREATMENT (Hypothesis: H30)
filename <- paste(sep="",base,"H30__H33.txt")
results <- read.table(filename, header = TRUE, sep = '|')
results$Closed...A <- ordered(results$Closed...A, levels = c("", "X"))
results$Closed...B <- ordered(results$Closed...B, levels = c("", "X"))
dataAC <- as.numeric(results$Closed...A)
dataBC <- as.numeric(results$Closed...B)
dataAC[is.na(dataAC)] <- 1
dataBC[is.na(dataAC)] <- 1
dataAC <- c(dataAC, 1)
dataBC <- c(dataBC, 1)
dataAC <- c(dataAC, 2)
dataBC <- c(dataBC, 2)
if(identical(dataAC,dataBC)) {
pvector = c(pvector, 1.0)
} else {
	testresult <- mcnemar.test(dataAC,dataBC)
	testresult
	pvector = c(pvector, testresult$p.value)
}

#QUANTIFIER TREATMENT (Hypothesis: H31)
filename <- paste(sep="",base,"H31__H34.txt")
results <- read.table(filename, header = TRUE, sep = '|')
results$Closed...A <- ordered(results$Closed...A, levels = c("", "X"))
results$Closed...B <- ordered(results$Closed...B, levels = c("", "X"))
dataAC <- as.numeric(results$Closed...A)
dataBC <- as.numeric(results$Closed...B)
dataAC[is.na(dataAC)] <- 1
dataBC[is.na(dataAC)] <- 1
dataAC <- c(dataAC, 1)
dataBC <- c(dataBC, 1)
dataAC <- c(dataAC, 2)
dataBC <- c(dataBC, 2)
if(identical(dataAC,dataBC)) {
pvector = c(pvector, 1.0)
} else {
	testresult <- mcnemar.test(dataAC,dataBC)
	testresult
	pvector = c(pvector, testresult$p.value)
}

#QUANTIFIER TREATMENT (Hypothesis: H32)
filename <- paste(sep="",base,"H29__H32.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
if(nrow(dataFilter) > 0)  {
	dataAN <- as.numeric(dataFilter$Effort...A)
	dataBN <- as.numeric(dataFilter$Effort...B)
	testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "greater")
	testresult
	pvector = c(pvector, testresult$p.value)
} else {
pvector = c(pvector, 1.0)
}

#QUANTIFIER TREATMENT (Hypothesis: H33)
filename <- paste(sep="",base,"H30__H33.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
if(nrow(dataFilter) > 0)  {
	dataAN <- as.numeric(dataFilter$Effort...A)
	dataBN <- as.numeric(dataFilter$Effort...B)
	testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "greater")
	testresult
	pvector = c(pvector, testresult$p.value)
} else {
pvector = c(pvector, 1.0)
}

#QUANTIFIER TREATMENT (Hypothesis: H34)
filename <- paste(sep="",base,"H31__H34.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
if(nrow(dataFilter) > 0)  {
	dataAN <- as.numeric(dataFilter$Effort...A)
	dataBN <- as.numeric(dataFilter$Effort...B)
	testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "greater")
	testresult
	pvector = c(pvector, testresult$p.value)
} else {
pvector = c(pvector, 1.0)
}

#QUANTIFIER TREATMENT (Hypothesis: H35)
filename <- paste(sep="",base,"H35.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
if(nrow(dataFilter) > 0)  {
	dataAN <- as.numeric(dataFilter$Effort...A)
	dataBN <- as.numeric(dataFilter$Effort...B)
	testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "less")
	testresult
	pvector = c(pvector, testresult$p.value)
} else {
pvector = c(pvector, 1.0)
}

#QUANTIFIER TREATMENT (Hypothesis: H36)
filename <- paste(sep="",base,"H36.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
if(nrow(dataFilter) > 0)  {
	dataAN <- as.numeric(dataFilter$Effort...A)
	dataBN <- as.numeric(dataFilter$Effort...B)
	testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "less")
	testresult
	pvector = c(pvector, testresult$p.value)
} else {
pvector = c(pvector, 1.0)
}

#QUANTIFIER TREATMENT (Hypothesis: H37)
filename <- paste(sep="",base,"H37.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
if(nrow(dataFilter) > 0)  {
	dataAN <- as.numeric(dataFilter$Effort...A)
	dataBN <- as.numeric(dataFilter$Effort...B)
	testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "less")
	testresult
	pvector = c(pvector, testresult$p.value)
} else {
pvector = c(pvector, 1.0)
}

#QUANTIFIER TREATMENT (Hypothesis: H38)
filename <- paste(sep="",base,"H38.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
if(nrow(dataFilter) > 0)  {
	dataAN <- as.numeric(dataFilter$Effort...A)
	dataBN <- as.numeric(dataFilter$Effort...B)
	testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "less")
	testresult
	pvector = c(pvector, testresult$p.value)
} else {
pvector = c(pvector, 1.0)
}

#CLASS AXIOM RULE (Hypothesis: H39)
filename <- paste(sep="",base,"H39__H42.txt")
results <- read.table(filename, header = TRUE, sep = '|')
results$Closed...A <- ordered(results$Closed...A, levels = c("", "X"))
results$Closed...B <- ordered(results$Closed...B, levels = c("", "X"))
dataAC <- as.numeric(results$Closed...A)
dataBC <- as.numeric(results$Closed...B)
dataAC[is.na(dataAC)] <- 1
dataBC[is.na(dataAC)] <- 1
dataAC <- c(dataAC, 1)
dataBC <- c(dataBC, 1)
dataAC <- c(dataAC, 2)
dataBC <- c(dataBC, 2)
if(identical(dataAC,dataBC)) {
pvector = c(pvector, 1.0)
} else {
	testresult <- mcnemar.test(dataAC,dataBC)
	testresult
	pvector = c(pvector, testresult$p.value)
}

#CLASS AXIOM RULE (Hypothesis: H40)
filename <- paste(sep="",base,"H40.txt")
results <- read.table(filename, header = TRUE, sep = '|')
results$Closed...A <- ordered(results$Closed...A, levels = c("", "X"))
results$Closed...B <- ordered(results$Closed...B, levels = c("", "X"))
dataAC <- as.numeric(results$Closed...A)
dataBC <- as.numeric(results$Closed...B)
dataAC[is.na(dataAC)] <- 1
dataBC[is.na(dataAC)] <- 1
dataAC <- c(dataAC, 1)
dataBC <- c(dataBC, 1)
dataAC <- c(dataAC, 2)
dataBC <- c(dataBC, 2)
if(identical(dataAC,dataBC)) {
pvector = c(pvector, 1.0)
} else {
	testresult <- mcnemar.test(dataAC,dataBC)
	testresult
	pvector = c(pvector, testresult$p.value)
}

#CLASS AXIOM RULE (Hypothesis: H41)
filename <- paste(sep="",base,"H41.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
if(nrow(dataFilter) > 0)  {
	dataAN <- as.numeric(dataFilter$Effort...A)
	dataBN <- as.numeric(dataFilter$Effort...B)
	testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "greater")
	testresult
	pvector = c(pvector, testresult$p.value)
} else {
pvector = c(pvector, 1.0)
}

#CLASS AXIOM RULE (Hypothesis: H42)
filename <- paste(sep="",base,"H39__H42.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
if(nrow(dataFilter) > 0)  {
	dataAN <- as.numeric(dataFilter$Effort...A)
	dataBN <- as.numeric(dataFilter$Effort...B)
	testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "greater")
	testresult
	pvector = c(pvector, testresult$p.value)
} else {
pvector = c(pvector, 1.0)
}

#CLASS AXIOM RULE (Hypothesis: H43)
filename <- paste(sep="",base,"H43.txt")
results <- read.table(filename, header = TRUE, sep = '|')
results$Closed...A <- ordered(results$Closed...A, levels = c("", "X"))
results$Closed...B <- ordered(results$Closed...B, levels = c("", "X"))
dataAC <- as.numeric(results$Closed...A)
dataBC <- as.numeric(results$Closed...B)
dataAC[is.na(dataAC)] <- 1
dataBC[is.na(dataAC)] <- 1
dataAC <- c(dataAC, 1)
dataBC <- c(dataBC, 1)
dataAC <- c(dataAC, 2)
dataBC <- c(dataBC, 2)
if(identical(dataAC,dataBC)) {
pvector = c(pvector, 1.0)
} else {
	testresult <- mcnemar.test(dataAC,dataBC)
	testresult
	pvector = c(pvector, testresult$p.value)
}

#CLASS AXIOM RULE (Hypothesis: H44)
filename <- paste(sep="",base,"H44.txt")
results <- read.table(filename, header = TRUE, sep = '|')
results$Closed...A <- ordered(results$Closed...A, levels = c("", "X"))
results$Closed...B <- ordered(results$Closed...B, levels = c("", "X"))
dataAC <- as.numeric(results$Closed...A)
dataBC <- as.numeric(results$Closed...B)
dataAC[is.na(dataAC)] <- 1
dataBC[is.na(dataAC)] <- 1
dataAC <- c(dataAC, 1)
dataBC <- c(dataBC, 1)
dataAC <- c(dataAC, 2)
dataBC <- c(dataBC, 2)
if(identical(dataAC,dataBC)) {
pvector = c(pvector, 1.0)
} else {
	testresult <- mcnemar.test(dataAC,dataBC)
	testresult
	pvector = c(pvector, testresult$p.value)
}

#CLASS AXIOM RULE (Hypothesis: H45)
filename <- paste(sep="",base,"H45__H50.txt")
results <- read.table(filename, header = TRUE, sep = '|')
results$Closed...A <- ordered(results$Closed...A, levels = c("", "X"))
results$Closed...B <- ordered(results$Closed...B, levels = c("", "X"))
dataAC <- as.numeric(results$Closed...A)
dataBC <- as.numeric(results$Closed...B)
dataAC[is.na(dataAC)] <- 1
dataBC[is.na(dataAC)] <- 1
dataAC <- c(dataAC, 1)
dataBC <- c(dataBC, 1)
dataAC <- c(dataAC, 2)
dataBC <- c(dataBC, 2)
if(identical(dataAC,dataBC)) {
pvector = c(pvector, 1.0)
} else {
	testresult <- mcnemar.test(dataAC,dataBC)
	testresult
	pvector = c(pvector, testresult$p.value)
}

#CLASS AXIOM RULE (Hypothesis: H46)
filename <- paste(sep="",base,"H46.txt")
results <- read.table(filename, header = TRUE, sep = '|')
results$Closed...A <- ordered(results$Closed...A, levels = c("", "X"))
results$Closed...B <- ordered(results$Closed...B, levels = c("", "X"))
dataAC <- as.numeric(results$Closed...A)
dataBC <- as.numeric(results$Closed...B)
dataAC[is.na(dataAC)] <- 1
dataBC[is.na(dataAC)] <- 1
dataAC <- c(dataAC, 1)
dataBC <- c(dataBC, 1)
dataAC <- c(dataAC, 2)
dataBC <- c(dataBC, 2)
if(identical(dataAC,dataBC)) {
pvector = c(pvector, 1.0)
} else {
	testresult <- mcnemar.test(dataAC,dataBC)
	testresult
	pvector = c(pvector, testresult$p.value)
}

#CLASS AXIOM RULE (Hypothesis: H47)
filename <- paste(sep="",base,"H47.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
if(nrow(dataFilter) > 0)  {
	dataAN <- as.numeric(dataFilter$Effort...A)
	dataBN <- as.numeric(dataFilter$Effort...B)
	testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "less")
	testresult
	pvector = c(pvector, testresult$p.value)
} else {
pvector = c(pvector, 1.0)
}

#CLASS AXIOM RULE (Hypothesis: H48)
filename <- paste(sep="",base,"H48.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
if(nrow(dataFilter) > 0)  {
	dataAN <- as.numeric(dataFilter$Effort...A)
	dataBN <- as.numeric(dataFilter$Effort...B)
	testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "less")
	testresult
	pvector = c(pvector, testresult$p.value)
} else {
pvector = c(pvector, 1.0)
}

#CLASS AXIOM RULE (Hypothesis: H49)
filename <- paste(sep="",base,"H49.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
if(nrow(dataFilter) > 0)  {
	dataAN <- as.numeric(dataFilter$Effort...A)
	dataBN <- as.numeric(dataFilter$Effort...B)
	testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "less")
	testresult
	pvector = c(pvector, testresult$p.value)
} else {
pvector = c(pvector, 1.0)
}

#CLASS AXIOM RULE (Hypothesis: H50)
filename <- paste(sep="",base,"H45__H50.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
if(nrow(dataFilter) > 0)  {
	dataAN <- as.numeric(dataFilter$Effort...A)
	dataBN <- as.numeric(dataFilter$Effort...B)
	testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "greater")
	testresult
	pvector = c(pvector, testresult$p.value)
} else {
pvector = c(pvector, 1.0)
}

#CLASS AXIOM RULE (Hypothesis: H51)
filename <- paste(sep="",base,"H51.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
if(nrow(dataFilter) > 0)  {
	dataAN <- as.numeric(dataFilter$Effort...A)
	dataBN <- as.numeric(dataFilter$Effort...B)
	testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "greater")
	testresult
	pvector = c(pvector, testresult$p.value)
} else {
pvector = c(pvector, 1.0)
}

#CLASS AXIOM RULE (Hypothesis: H52)
filename <- paste(sep="",base,"H52.txt")
results <- read.table(filename, header = TRUE, sep = '|')
### EMPTY experiment (or too few elements)!!!! So, this hypothesis will be skipped
pvector = c(pvector, 1.0)

#STRINGS (Hypothesis: H53)
filename <- paste(sep="",base,"H53.txt")
results <- read.table(filename, header = TRUE, sep = '|')
results$Closed...A <- ordered(results$Closed...A, levels = c("", "X"))
results$Closed...B <- ordered(results$Closed...B, levels = c("", "X"))
dataAC <- as.numeric(results$Closed...A)
dataBC <- as.numeric(results$Closed...B)
dataAC[is.na(dataAC)] <- 1
dataBC[is.na(dataAC)] <- 1
dataAC <- c(dataAC, 1)
dataBC <- c(dataBC, 1)
dataAC <- c(dataAC, 2)
dataBC <- c(dataBC, 2)
if(identical(dataAC,dataBC)) {
pvector = c(pvector, 1.0)
} else {
	testresult <- mcnemar.test(dataAC,dataBC)
	testresult
	pvector = c(pvector, testresult$p.value)
}

#BIGINT (Hypothesis: H54)
filename <- paste(sep="",base,"H54.txt")
results <- read.table(filename, header = TRUE, sep = '|')
results$Closed...A <- ordered(results$Closed...A, levels = c("", "X"))
results$Closed...B <- ordered(results$Closed...B, levels = c("", "X"))
dataAC <- as.numeric(results$Closed...A)
dataBC <- as.numeric(results$Closed...B)
dataAC[is.na(dataAC)] <- 1
dataBC[is.na(dataAC)] <- 1
dataAC <- c(dataAC, 1)
dataBC <- c(dataBC, 1)
dataAC <- c(dataAC, 2)
dataBC <- c(dataBC, 2)
if(identical(dataAC,dataBC)) {
pvector = c(pvector, 1.0)
} else {
	testresult <- mcnemar.test(dataAC,dataBC)
	testresult
	pvector = c(pvector, testresult$p.value)
}

#INTEGERSIMPLIFICATIONRULES (Hypothesis: H55)
filename <- paste(sep="",base,"H55.txt")
results <- read.table(filename, header = TRUE, sep = '|')
results$Closed...A <- ordered(results$Closed...A, levels = c("", "X"))
results$Closed...B <- ordered(results$Closed...B, levels = c("", "X"))
dataAC <- as.numeric(results$Closed...A)
dataBC <- as.numeric(results$Closed...B)
dataAC[is.na(dataAC)] <- 1
dataBC[is.na(dataAC)] <- 1
dataAC <- c(dataAC, 1)
dataBC <- c(dataBC, 1)
dataAC <- c(dataAC, 2)
dataBC <- c(dataBC, 2)
if(identical(dataAC,dataBC)) {
pvector = c(pvector, 1.0)
} else {
	testresult <- mcnemar.test(dataAC,dataBC)
	testresult
	pvector = c(pvector, testresult$p.value)
}

#INTEGERSIMPLIFICATIONRULES (Hypothesis: H56)
filename <- paste(sep="",base,"H56.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
if(nrow(dataFilter) > 0)  {
	dataAN <- as.numeric(dataFilter$Effort...A)
	dataBN <- as.numeric(dataFilter$Effort...B)
	testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "less")
	testresult
	pvector = c(pvector, testresult$p.value)
} else {
pvector = c(pvector, 1.0)
}

#INTEGERSIMPLIFICATIONRULES (Hypothesis: H57)
filename <- paste(sep="",base,"H57.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
if(nrow(dataFilter) > 0)  {
	dataAN <- as.numeric(dataFilter$Effort...A)
	dataBN <- as.numeric(dataFilter$Effort...B)
	testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "less")
	testresult
	pvector = c(pvector, testresult$p.value)
} else {
pvector = c(pvector, 1.0)
}

#INTEGERSIMPLIFICATIONRULES (Hypothesis: H58)
filename <- paste(sep="",base,"H58.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
if(nrow(dataFilter) > 0)  {
	dataAN <- as.numeric(dataFilter$Effort...A)
	dataBN <- as.numeric(dataFilter$Effort...B)
	testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "less")
	testresult
	pvector = c(pvector, testresult$p.value)
} else {
pvector = c(pvector, 1.0)
}

#SEQUENCES (Hypothesis: H59)
filename <- paste(sep="",base,"H59.txt")
results <- read.table(filename, header = TRUE, sep = '|')
results$Closed...A <- ordered(results$Closed...A, levels = c("", "X"))
results$Closed...B <- ordered(results$Closed...B, levels = c("", "X"))
dataAC <- as.numeric(results$Closed...A)
dataBC <- as.numeric(results$Closed...B)
dataAC[is.na(dataAC)] <- 1
dataBC[is.na(dataAC)] <- 1
dataAC <- c(dataAC, 1)
dataBC <- c(dataBC, 1)
dataAC <- c(dataAC, 2)
dataBC <- c(dataBC, 2)
if(identical(dataAC,dataBC)) {
pvector = c(pvector, 1.0)
} else {
	testresult <- mcnemar.test(dataAC,dataBC)
	testresult
	pvector = c(pvector, testresult$p.value)
}

#MORESEQRULES (Hypothesis: H60)
filename <- paste(sep="",base,"H60.txt")
results <- read.table(filename, header = TRUE, sep = '|')
results$Closed...A <- ordered(results$Closed...A, levels = c("", "X"))
results$Closed...B <- ordered(results$Closed...B, levels = c("", "X"))
dataAC <- as.numeric(results$Closed...A)
dataBC <- as.numeric(results$Closed...B)
dataAC[is.na(dataAC)] <- 1
dataBC[is.na(dataAC)] <- 1
dataAC <- c(dataAC, 1)
dataBC <- c(dataBC, 1)
dataAC <- c(dataAC, 2)
dataBC <- c(dataBC, 2)
if(identical(dataAC,dataBC)) {
pvector = c(pvector, 1.0)
} else {
	testresult <- mcnemar.test(dataAC,dataBC)
	testresult
	pvector = c(pvector, testresult$p.value)
}

pvaluef <- file("F:/Homeoffice/ResearchProjects/ICSE21-Guido/framework/Guido/Plugins/de.tubs.isf.guido.evaluation/./testData/keyproject/R/pValues.txt")
write(pvector, file = pvaluef, sep = "\n")
unlink(pvaluef) # tidy up
