package java.lang;

public class AssertionError extends java.lang.Error {
    public AssertionError() {}
    public AssertionError(java.lang.Object detailMessage) {}
    public AssertionError(boolean detailMessage){}
    public AssertionError(char detailMessage)   {}
//    public AssertionError(double detailMessage) {}
//    public AssertionError(float detailMessage)  {}
    public AssertionError(int detailMessage)    {}
    public AssertionError(long detailMessage)   {}
}
