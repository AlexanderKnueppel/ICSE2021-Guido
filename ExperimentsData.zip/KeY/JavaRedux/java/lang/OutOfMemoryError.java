


package java.lang;
public class OutOfMemoryError extends java.lang.VirtualMachineError {
    public OutOfMemoryError() {}
    public OutOfMemoryError(java.lang.String arg0) {}
}
