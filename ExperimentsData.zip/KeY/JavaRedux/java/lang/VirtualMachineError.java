


package java.lang;
public abstract class VirtualMachineError extends java.lang.Error {
    public VirtualMachineError() {}
    public VirtualMachineError(java.lang.String arg0) {}
}
