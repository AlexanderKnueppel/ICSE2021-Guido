
file name          Listing number in KeY Book

PostInc.java             16.1
Sort.java                16.2
SortPerm.java            16.3



PostInc.proof          proof of the only contract in PostInc.java
Sort_max.proof         proof of contract for max in Sort.java
SortPerm_max.proof     proof of contract for max in SortPerm.java
SortPerm_sort.proof    proof of contract for sort in Sort.java
Sort_sort.proof        proof of contract for sort in Sort<Perm.java


All proofs complete automatically with the standard proof settings
except for SortPerm_sort. For this proof follow the instructions on
pages 564-565 of the Key book.