base <- "path/to/experiments/"

#CPA.SMG.EXPORTSMGWHEN (Hypothesis: H3)
filename <- paste(sep="",base,"H2__H3__H5.txt")
results <- read.table(filename, header = TRUE, sep = '|')
tabl <- with(results , table(results$Closed...A, results$Closed...B))
addmargins(tabl)

#CPA.SMG.EXPORTSMGWHEN (Hypothesis: H5)
filename <- paste(sep="",base,"H2__H3__H5.txt")
results <- read.table(filename, header = TRUE, sep = '|')
tabl <- with(results , table(results$Closed...A, results$Closed...B))
addmargins(tabl)

#ANALYSIS.SUMMARYEDGES (Hypothesis: H14)
filename <- paste(sep="",base,"H14.txt")
results <- read.table(filename, header = TRUE, sep = '|')
tabl <- with(results , table(results$Closed...A, results$Closed...B))
addmargins(tabl)

#ANALYSIS.USEPARALLELANALYSES (Hypothesis: H26)
filename <- paste(sep="",base,"H26.txt")
results <- read.table(filename, header = TRUE, sep = '|')
tabl <- with(results , table(results$Closed...A, results$Closed...B))
addmargins(tabl)

#CPA.SMG.RUNTIMECHECK (Hypothesis: H32)
filename <- paste(sep="",base,"H31__H32.txt")
results <- read.table(filename, header = TRUE, sep = '|')
tabl <- with(results , table(results$Closed...A, results$Closed...B))
addmargins(tabl)
