#!/bin/bash
RScript ./experiments.r > ./expOutput.txt
