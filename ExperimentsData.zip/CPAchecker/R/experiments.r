base <- "path/to/experiments/"

#CPA.SMG.EXPORTSMGWHEN (Hypothesis: H0)
filename <- paste(sep="",base,"H0.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
dataAN <- as.numeric(dataFilter$Effort...A)
dataBN <- as.numeric(dataFilter$Effort...B)
testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "greater")
testresult
pvector = c(testresult$p.value)

#CPA.SMG.EXPORTSMGWHEN (Hypothesis: H1)
filename <- paste(sep="",base,"H1.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
dataAN <- as.numeric(dataFilter$Effort...A)
dataBN <- as.numeric(dataFilter$Effort...B)
testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "greater")
testresult
pvector = c(pvector, testresult$p.value)

#CPA.SMG.EXPORTSMGWHEN (Hypothesis: H2)
filename <- paste(sep="",base,"H2__H3__H5.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
dataAN <- as.numeric(dataFilter$Effort...A)
dataBN <- as.numeric(dataFilter$Effort...B)
testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "greater")
testresult
pvector = c(pvector, testresult$p.value)

#CPA.SMG.EXPORTSMGWHEN (Hypothesis: H3)
filename <- paste(sep="",base,"H2__H3__H5.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataAC <- as.numeric(results$Closed...A)
dataBC <- as.numeric(results$Closed...B)
testresult <- mcnemar.test(dataAC,dataBC)
testresult
pvector = c(pvector, testresult$p.value)

#CPA.SMG.EXPORTSMGWHEN (Hypothesis: H4)
filename <- paste(sep="",base,"H4.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
dataAN <- as.numeric(dataFilter$Effort...A)
dataBN <- as.numeric(dataFilter$Effort...B)
testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "greater")
testresult
pvector = c(pvector, testresult$p.value)

#CPA.SMG.EXPORTSMGWHEN (Hypothesis: H5)
filename <- paste(sep="",base,"H2__H3__H5.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataAC <- as.numeric(results$Closed...A)
dataBC <- as.numeric(results$Closed...B)
testresult <- mcnemar.test(dataAC,dataBC)
testresult
pvector = c(pvector, testresult$p.value)

#CPA.SMG.EXPORTSMGWHEN (Hypothesis: H6)
filename <- paste(sep="",base,"H6.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
dataAN <- as.numeric(dataFilter$Effort...A)
dataBN <- as.numeric(dataFilter$Effort...B)
testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "greater")
testresult
pvector = c(pvector, testresult$p.value)

#CPA.SMG.EXPORTSMGWHEN (Hypothesis: H7)
filename <- paste(sep="",base,"H7__H8.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
dataAN <- as.numeric(dataFilter$Effort...A)
dataBN <- as.numeric(dataFilter$Effort...B)
testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "less")
testresult
pvector = c(pvector, testresult$p.value)

#CPA.SMG.EXPORTSMGWHEN (Hypothesis: H8)
filename <- paste(sep="",base,"H7__H8.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
dataAN <- as.numeric(dataFilter$Effort...A)
dataBN <- as.numeric(dataFilter$Effort...B)
testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "greater")
testresult
pvector = c(pvector, testresult$p.value)

#CPA.SMG.EXPORTSMGWHEN (Hypothesis: H9)
filename <- paste(sep="",base,"H9.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
dataAN <- as.numeric(dataFilter$Effort...A)
dataBN <- as.numeric(dataFilter$Effort...B)
testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "greater")
testresult
pvector = c(pvector, testresult$p.value)

#CPA.SMG.EXPORTSMGWHEN (Hypothesis: H10)
filename <- paste(sep="",base,"H10.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
dataAN <- as.numeric(dataFilter$Effort...A)
dataBN <- as.numeric(dataFilter$Effort...B)
testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "greater")
testresult
pvector = c(pvector, testresult$p.value)

#CPA.SMG.UNKNOWNONUNDEFINED (Hypothesis: H11)
filename <- paste(sep="",base,"H11.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
dataAN <- as.numeric(dataFilter$Effort...A)
dataBN <- as.numeric(dataFilter$Effort...B)
testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "less")
testresult
pvector = c(pvector, testresult$p.value)

#CPA.SMG.UNKNOWNONUNDEFINED (Hypothesis: H12)
filename <- paste(sep="",base,"H12.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
dataAN <- as.numeric(dataFilter$Effort...A)
dataBN <- as.numeric(dataFilter$Effort...B)
testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "less")
testresult
pvector = c(pvector, testresult$p.value)

#CPA.SMG.UNKNOWNONUNDEFINED (Hypothesis: H13)
filename <- paste(sep="",base,"H13.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
dataAN <- as.numeric(dataFilter$Effort...A)
dataBN <- as.numeric(dataFilter$Effort...B)
testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "less")
testresult
pvector = c(pvector, testresult$p.value)

#ANALYSIS.SUMMARYEDGES (Hypothesis: H14)
filename <- paste(sep="",base,"H14.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataAC <- as.numeric(results$Closed...A)
dataBC <- as.numeric(results$Closed...B)
testresult <- mcnemar.test(dataAC,dataBC)
testresult
pvector = c(pvector, testresult$p.value)

#CFA.SIMPLIFYCONSTEXPRESSIONS (Hypothesis: H15)
filename <- paste(sep="",base,"H15.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
dataAN <- as.numeric(dataFilter$Effort...A)
dataBN <- as.numeric(dataFilter$Effort...B)
testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "greater")
testresult
pvector = c(pvector, testresult$p.value)

#CFA.SIMPLIFYCONSTEXPRESSIONS (Hypothesis: H16)
filename <- paste(sep="",base,"H16.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
dataAN <- as.numeric(dataFilter$Effort...A)
dataBN <- as.numeric(dataFilter$Effort...B)
testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "greater")
testresult
pvector = c(pvector, testresult$p.value)

#CFA.SIMPLIFYCONSTEXPRESSIONS (Hypothesis: H17)
filename <- paste(sep="",base,"H17.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
dataAN <- as.numeric(dataFilter$Effort...A)
dataBN <- as.numeric(dataFilter$Effort...B)
testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "greater")
testresult
pvector = c(pvector, testresult$p.value)

#CFA.SIMPLIFYCONSTEXPRESSIONS (Hypothesis: H18)
filename <- paste(sep="",base,"H18.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
dataAN <- as.numeric(dataFilter$Effort...A)
dataBN <- as.numeric(dataFilter$Effort...B)
testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "greater")
testresult
pvector = c(pvector, testresult$p.value)

#CFA.SIMPLIFYCONSTEXPRESSIONS (Hypothesis: H19)
filename <- paste(sep="",base,"H19.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
dataAN <- as.numeric(dataFilter$Effort...A)
dataBN <- as.numeric(dataFilter$Effort...B)
testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "greater")
testresult
pvector = c(pvector, testresult$p.value)

#CFA.FINDLIVEVARIABLES (Hypothesis: H20)
filename <- paste(sep="",base,"H20.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
dataAN <- as.numeric(dataFilter$Effort...A)
dataBN <- as.numeric(dataFilter$Effort...B)
testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "greater")
testresult
pvector = c(pvector, testresult$p.value)

#CFA.FINDLIVEVARIABLES (Hypothesis: H21)
filename <- paste(sep="",base,"H21.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
dataAN <- as.numeric(dataFilter$Effort...A)
dataBN <- as.numeric(dataFilter$Effort...B)
testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "greater")
testresult
pvector = c(pvector, testresult$p.value)

#CFA.FINDLIVEVARIABLES (Hypothesis: H22)
filename <- paste(sep="",base,"H22.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
dataAN <- as.numeric(dataFilter$Effort...A)
dataBN <- as.numeric(dataFilter$Effort...B)
testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "greater")
testresult
pvector = c(pvector, testresult$p.value)

#CFA.FINDLIVEVARIABLES (Hypothesis: H23)
filename <- paste(sep="",base,"H23.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
dataAN <- as.numeric(dataFilter$Effort...A)
dataBN <- as.numeric(dataFilter$Effort...B)
testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "greater")
testresult
pvector = c(pvector, testresult$p.value)

#CFA.FINDLIVEVARIABLES (Hypothesis: H24)
filename <- paste(sep="",base,"H24.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
dataAN <- as.numeric(dataFilter$Effort...A)
dataBN <- as.numeric(dataFilter$Effort...B)
testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "greater")
testresult
pvector = c(pvector, testresult$p.value)

#CPA.PREDICATE.HANDLESTRINGLITERALINITIALIZERS (Hypothesis: H25)
filename <- paste(sep="",base,"H25.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
dataAN <- as.numeric(dataFilter$Effort...A)
dataBN <- as.numeric(dataFilter$Effort...B)
testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "less")
testresult
pvector = c(pvector, testresult$p.value)

#ANALYSIS.USEPARALLELANALYSES (Hypothesis: H26)
filename <- paste(sep="",base,"H26.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataAC <- as.numeric(results$Closed...A)
dataBC <- as.numeric(results$Closed...B)
testresult <- mcnemar.test(dataAC,dataBC)
testresult
pvector = c(pvector, testresult$p.value)

#CPA.INVARIANTS.ABSTRACTIONSTATEFACTORY (Hypothesis: H27)
filename <- paste(sep="",base,"H27.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
dataAN <- as.numeric(dataFilter$Effort...A)
dataBN <- as.numeric(dataFilter$Effort...B)
testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "less")
testresult
pvector = c(pvector, testresult$p.value)

#CPA.INVARIANTS.ABSTRACTIONSTATEFACTORY (Hypothesis: H28)
filename <- paste(sep="",base,"H28.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
dataAN <- as.numeric(dataFilter$Effort...A)
dataBN <- as.numeric(dataFilter$Effort...B)
testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "less")
testresult
pvector = c(pvector, testresult$p.value)

#CPA.INVARIANTS.ABSTRACTIONSTATEFACTORY (Hypothesis: H29)
filename <- paste(sep="",base,"H29.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
dataAN <- as.numeric(dataFilter$Effort...A)
dataBN <- as.numeric(dataFilter$Effort...B)
testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "less")
testresult
pvector = c(pvector, testresult$p.value)

#CPA.INVARIANTS.ABSTRACTIONSTATEFACTORY (Hypothesis: H30)
filename <- paste(sep="",base,"H30.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
dataAN <- as.numeric(dataFilter$Effort...A)
dataBN <- as.numeric(dataFilter$Effort...B)
testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "less")
testresult
pvector = c(pvector, testresult$p.value)

#CPA.SMG.RUNTIMECHECK (Hypothesis: H31)
filename <- paste(sep="",base,"H31__H32.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataFilter <- subset(results, Closed...A == Closed...B & Closed...A =="X")
dataAN <- as.numeric(dataFilter$Effort...A)
dataBN <- as.numeric(dataFilter$Effort...B)
testresult <- wilcox.test(dataAN, dataBN, paired=TRUE, alternative = "less")
testresult
pvector = c(pvector, testresult$p.value)

#CPA.SMG.RUNTIMECHECK (Hypothesis: H32)
filename <- paste(sep="",base,"H31__H32.txt")
results <- read.table(filename, header = TRUE, sep = '|')
dataAC <- as.numeric(results$Closed...A)
dataBC <- as.numeric(results$Closed...B)
testresult <- mcnemar.test(dataAC,dataBC)
testresult
pvector = c(pvector, testresult$p.value)

pvaluef <- file("./pValues.txt")
write(pvector, file = pvaluef, sep = "\n")
unlink(pvaluef) # tidy up
